<?php return [
    'db' => [
        'host' => 'db',
        'port' => 3306,
        'user' => 'root',
        'pass' => 'secret',
        'dbname' => 'foo',
    ],
    'displayErrorDetails' => true,
    'addContentLengthHeader' => false,
];
